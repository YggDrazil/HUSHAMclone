import xbmcaddon

MainBase = 'https://goo.gl/0ENMGE'
addon = xbmcaddon.Addon('plugin.video.DCSports')