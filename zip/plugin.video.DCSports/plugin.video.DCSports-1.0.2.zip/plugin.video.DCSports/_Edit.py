import xbmcaddon

MainBase = 'https://goo.gl/K4osoQ'
addon = xbmcaddon.Addon('plugin.video.DCSports')