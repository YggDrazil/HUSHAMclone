#Youtube channels
#
#
#
#
#
#Husham Memar
import re
import os
import sys
import urllib2
import buggalo
import xbmcgui
import xbmcaddon
import xbmcplugin

BASE_URL = 'http://www.husham.com/?p=11081'
PLAY_VIDEO_PATH = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s'
PLAYLIST_PATH = 'plugin://plugin.video.youtube/user/hmemar22/'
PLAYLIST_PATH2 = 'plugin://plugin.video.youtube/user/ARUEIRA23/'
PLAYLIST_PATH3 = 'plugin://plugin.video.youtube/channel/UCHO6YXkVn6Dzd-v3Z1sIjJA/'


if __name__ == '__main__':
    ADDON = xbmcaddon.Addon()
    HANDLE = int(sys.argv[1])

    try:
        u = urllib2.urlopen(BASE_URL)
        html = u.read()
        u.close()


        m = re.search('//www.youtube.com/embed/([^"]+)"', html, re.DOTALL)
        if m:
            item = xbmcgui.ListItem('Husham Memar Guides',
                                    ADDON.getLocalizedString(30001),
                                    iconImage='https://raw.githubusercontent.com/hmemar/husham.com/master/repo/aaa/husham.png')
            xbmcplugin.addDirectoryItem(HANDLE, PLAYLIST_PATH, item, True)
            item = xbmcgui.ListItem('Teddy Bad Boy',
                                    ADDON.getLocalizedString(30001),
                                    iconImage='https://raw.githubusercontent.com/hmemar/husham.com/master/repo/aaa/badboy.JPG')
            xbmcplugin.addDirectoryItem(HANDLE, PLAYLIST_PATH2, item, True)
            item = xbmcgui.ListItem('Kybo Fire Guides',
                                    ADDON.getLocalizedString(30001),
                                    iconImage='https://raw.githubusercontent.com/hmemar/husham.com/master/repo/aaa/Kybo.JPG')
            xbmcplugin.addDirectoryItem(HANDLE, PLAYLIST_PATH3, item, True)
            
        xbmcplugin.endOfDirectory(HANDLE)
    except:
        buggalo.onExceptionRaised()
